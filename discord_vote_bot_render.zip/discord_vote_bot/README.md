# Discord Vote Bot (Render)

## 파일
- `main.py`: Discord slash command + FastAPI website + OAuth2 + PostgreSQL vote storage
- `requirements.txt`: Python dependencies

## Render setup
1. Create a PostgreSQL database on Render.
2. Create a Web Service from this repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `python main.py`
5. Add environment variables listed below.
6. Deploy, then copy the service URL into `PUBLIC_BASE_URL` and redeploy.

## Environment variables
- `DISCORD_TOKEN`: Discord Developer Portal > Bot > token
- `DISCORD_CLIENT_ID`: Developer Portal > General Information > Application ID
- `DISCORD_CLIENT_SECRET`: Developer Portal > OAuth2 > Client Secret
- `DISCORD_GUILD_ID`: ID of the one Discord server allowed to vote
- `DATABASE_URL`: Render PostgreSQL Internal Database URL (if available)
- `SESSION_SECRET`: long random secret (at least 32 random characters)
- `PUBLIC_BASE_URL`: Render URL, e.g. `https://your-service.onrender.com`

## Discord OAuth2
In Developer Portal > OAuth2, add this exact redirect URI after your Render URL exists:
`https://YOUR-SERVICE.onrender.com/auth/callback`

The OAuth scope used is `identify`. Membership is independently checked server-side with the bot token.

## Bot setup
- Invite the bot to the target server with `bot` and `applications.commands` scopes.
- Give it permission to send messages and embed links in the channel where `/투표` is used.
- Set `DISCORD_GUILD_ID` to that server's ID.
- `/투표` is registered to that server for fast availability.

## Notes
- A unique database constraint `UNIQUE(vote_id, user_id)` enforces one ballot per Discord account per poll.
- This sample does not include poll closing or admin deletion.
- The Render service must remain running for the bot to stay connected. Free services may sleep; check current Render plan limits.
- Never put tokens or secrets into source code or publish them.
