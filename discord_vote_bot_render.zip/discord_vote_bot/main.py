import os
import json
import asyncio
import secrets
import html
from urllib.parse import urlencode

import aiohttp
import asyncpg
import discord
from discord import app_commands
from discord.ext import commands
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from starlette.middleware.sessions import SessionMiddleware
import uvicorn

DISCORD_TOKEN = os.environ["DISCORD_TOKEN"]
CLIENT_ID = os.environ["DISCORD_CLIENT_ID"]
CLIENT_SECRET = os.environ["DISCORD_CLIENT_SECRET"]
GUILD_ID = int(os.environ["DISCORD_GUILD_ID"])
DATABASE_URL = os.environ["DATABASE_URL"]
SESSION_SECRET = os.environ["SESSION_SECRET"]
PUBLIC_BASE_URL = os.environ["PUBLIC_BASE_URL"].rstrip("/")
OAUTH_REDIRECT_URI = f"{PUBLIC_BASE_URL}/auth/callback"

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)
app = FastAPI(title="Discord Vote")
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    https_only=True,
    same_site="lax",
    max_age=60 * 60 * 24 * 7,
)

pool = None
bot_task = None


async def db_init():
    global pool
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=5)
    async with pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS votes (
                id BIGSERIAL PRIMARY KEY,
                guild_id TEXT NOT NULL,
                creator_id TEXT NOT NULL,
                title TEXT NOT NULL,
                options JSONB NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS ballots (
                id BIGSERIAL PRIMARY KEY,
                vote_id BIGINT NOT NULL REFERENCES votes(id) ON DELETE CASCADE,
                user_id TEXT NOT NULL,
                option_index INTEGER NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE(vote_id, user_id)
            )
        """)


async def is_guild_member(user_id: str) -> bool:
    # Verify membership directly with Discord's API, not a browser-provided value.
    url = f"https://discord.com/api/v10/guilds/{GUILD_ID}/members/{user_id}"
    headers = {"Authorization": f"Bot {DISCORD_TOKEN}"}
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url, headers=headers) as response:
            if response.status == 200:
                return True
            if response.status == 404:
                return False
            if response.status == 401 or response.status == 403:
                raise RuntimeError(
                    "봇이 서버 멤버 정보를 확인할 수 없습니다. 봇 토큰과 서버 설정을 확인하세요."
                )
            raise RuntimeError(f"Discord 멤버 확인 실패: HTTP {response.status}")


async def get_discord_user(code: str):
    timeout = aiohttp.ClientTimeout(total=15)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        token_data = {
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": OAUTH_REDIRECT_URI,
        }
        async with session.post(
            "https://discord.com/api/v10/oauth2/token",
            data=token_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ) as response:
            if response.status != 200:
                raise HTTPException(400, "디스코드 로그인 토큰 교환에 실패했습니다.")
            token_json = await response.json()

        async with session.get(
            "https://discord.com/api/v10/users/@me",
            headers={"Authorization": f"Bearer {token_json['access_token']}"},
        ) as response:
            if response.status != 200:
                raise HTTPException(400, "디스코드 계정을 확인하지 못했습니다.")
            return await response.json()


@bot.event
async def on_ready():
    try:
        guild_obj = discord.Object(id=GUILD_ID)
        bot.tree.copy_global_to(guild=guild_obj)
        synced = await bot.tree.sync(guild=guild_obj)
        print(f"Discord 로그인 완료: {bot.user}; 서버 명령어 {len(synced)}개 동기화")
    except Exception as exc:
        print(f"슬래시 명령어 동기화 실패: {exc}")


@bot.tree.command(name="투표", description="웹사이트에서 참여하는 투표를 생성합니다.")
@app_commands.describe(선택지="쉼표로 구분한 선택지 (예: 사과, 바나나, 포도)")
async def create_vote(interaction: discord.Interaction, 선택지: str):
    if interaction.guild_id != GUILD_ID:
        await interaction.response.send_message(
            "이 투표봇은 설정된 서버에서만 사용할 수 있습니다.", ephemeral=True
        )
        return

    options = [part.strip() for part in 선택지.split(",") if part.strip()]
    # Avoid duplicates while preserving the user's order.
    options = list(dict.fromkeys(options))
    if len(options) < 2:
        await interaction.response.send_message(
            "선택지를 2개 이상 입력해 주세요. 예: `/투표 선택지: 사과, 바나나, 포도`",
            ephemeral=True,
        )
        return
    if len(options) > 10:
        await interaction.response.send_message("선택지는 최대 10개까지 가능합니다.", ephemeral=True)
        return
    if any(len(option) > 80 for option in options):
        await interaction.response.send_message("각 선택지는 80자 이하여야 합니다.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=False)
    async with pool.acquire() as conn:
        vote_id = await conn.fetchval(
            """
            INSERT INTO votes (guild_id, creator_id, title, options)
            VALUES ($1, $2, $3, $4::jsonb)
            RETURNING id
            """,
            str(GUILD_ID),
            str(interaction.user.id),
            " / ".join(options),
            json.dumps(options, ensure_ascii=False),
        )

    url = f"{PUBLIC_BASE_URL}/vote/{vote_id}"
    embed = discord.Embed(
        title="🗳️ 새 투표가 생성되었습니다",
        description=f"**선택지:**\n" + "\n".join(f"• {html.escape(x)}" for x in options),
        color=discord.Color.blurple(),
    )
    embed.add_field(name="투표 참여", value=f"[웹사이트 열기]({url})", inline=False)
    embed.set_footer(text="참여하려면 Discord 로그인 필요 · 계정당 1회")
    await interaction.followup.send(embed=embed, ephemeral=False)


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    user = request.session.get("user")
    login = (
        '<a class="button" href="/login">Discord로 로그인</a>'
        if not user
        else f'<p>로그인됨: <b>{html.escape(user.get("username", "Discord 사용자"))}</b></p>'
    )
    return HTMLResponse(f"""
    <!doctype html><html lang="ko"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>디스코드 투표</title>{STYLE}</head><body><main class="wrap">
    <section class="card"><div class="logo">🗳️</div><h1>디스코드 투표</h1>
    <p>디스코드 서버 멤버 전용 온라인 투표</p>{login}
    <p class="muted">투표 링크를 디스코드에서 열어 주세요.</p></section></main></body></html>
    """)


@app.get("/login")
async def login(request: Request, vote_id: str | None = None):
    state = secrets.token_urlsafe(24)
    request.session["oauth_state"] = state
    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": OAUTH_REDIRECT_URI,
        "scope": "identify",
        "state": state,
    }
    return RedirectResponse("https://discord.com/oauth2/authorize?" + urlencode(params))


@app.get("/auth/callback")
async def auth_callback(request: Request, code: str | None = None, state: str | None = None, error: str | None = None):
    if error:
        raise HTTPException(400, "디스코드 로그인이 취소되었습니다.")
    saved_state = request.session.get("oauth_state")
    request.session.pop("oauth_state", None)
    if not code or not state or not saved_state or not secrets.compare_digest(state, saved_state):
        raise HTTPException(400, "로그인 보안 확인에 실패했습니다. 다시 로그인해 주세요.")

    user = await get_discord_user(code)
    try:
        member = await is_guild_member(str(user["id"]))
    except Exception as exc:
        raise HTTPException(503, f"서버 멤버 확인에 실패했습니다: {exc}")
    if not member:
        request.session.clear()
        return HTMLResponse(f"""
        <!doctype html><html lang="ko"><head><meta charset="utf-8">{STYLE}</head>
        <body><main class="wrap"><section class="card"><h1>서버 멤버 전용</h1>
        <p>이 투표는 지정된 디스코드 서버의 멤버만 참여할 수 있습니다.</p>
        <a class="button" href="/">홈으로</a></section></main></body></html>
        """, status_code=403)

    request.session["user"] = {
        "id": str(user["id"]),
        "username": user.get("global_name") or user.get("username") or "Discord 사용자",
        "avatar": user.get("avatar"),
    }
    return RedirectResponse("/", status_code=303)


@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=303)


@app.get("/vote/{vote_id}", response_class=HTMLResponse)
async def vote_page(vote_id: int, request: Request):
    async with pool.acquire() as conn:
        vote = await conn.fetchrow("SELECT * FROM votes WHERE id=$1", vote_id)
    if not vote:
        raise HTTPException(404, "투표를 찾을 수 없습니다.")
    user = request.session.get("user")
    if not user:
        return HTMLResponse(f"""
        <!doctype html><html lang="ko"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">{STYLE}
        </head><body><main class="wrap"><section class="card"><div class="logo">🗳️</div>
        <h1>투표 참여</h1><p>참여하려면 디스코드 로그인이 필요합니다.</p>
        <a class="button" href="/login">Discord로 로그인</a>
        <p><a href="/">홈으로</a></p></section></main></body></html>
        """)
    try:
        member = await is_guild_member(user["id"])
    except Exception:
        raise HTTPException(503, "서버 멤버 확인에 실패했습니다. 잠시 후 다시 시도해 주세요.")
    if not member:
        request.session.clear()
        raise HTTPException(403, "지정된 디스코드 서버의 멤버만 투표할 수 있습니다.")

    options = vote["options"]
    if isinstance(options, str):
        options = json.loads(options)
    async with pool.acquire() as conn:
        already = await conn.fetchval(
            "SELECT 1 FROM ballots WHERE vote_id=$1 AND user_id=$2",
            vote_id, user["id"]
        )
    option_html = "".join(
        f'<label class="option"><input type="radio" name="option_index" value="{i}" required> '
        f'<span>{html.escape(option)}</span></label>'
        for i, option in enumerate(options)
    )
    if already:
        form_html = '<p class="success">이미 이 투표에 참여했습니다. 다시 투표할 수 없습니다.</p>'
    else:
        form_html = f"""
        <form method="post" action="/vote/{vote_id}/cast">
        <div class="options">{option_html}</div>
        <button class="button" type="submit">투표하기</button>
        </form>
        """
    return HTMLResponse(f"""
    <!doctype html><html lang="ko"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">{STYLE}</head>
    <body><main class="wrap"><section class="card"><div class="topline">DISCORD COMMUNITY POLL</div>
    <h1>🗳️ 투표</h1><p>로그인: <b>{html.escape(user["username"])}</b> · <a href="/logout">로그아웃</a></p>
    {form_html}<hr><h2>실시간 결과</h2><div id="results" class="results">결과 불러오는 중...</div>
    <p class="muted">득표수와 득표율은 자동으로 갱신됩니다.</p></section></main>
    <script>
    async function refreshResults() {{
      try {{
        const r = await fetch('/api/vote/{vote_id}', {{cache:'no-store'}});
        if (!r.ok) throw new Error('결과를 불러오지 못했습니다.');
        const d = await r.json();
        document.getElementById('results').innerHTML = d.results.map(x =>
          `<div class="result"><div class="result-head"><span>${{escapeHtml(x.option)}}</span><b>${{x.count}}표 · ${{x.percent}}%</b></div><div class="bar"><span style="width:${{x.percent}}%"></span></div></div>`
        ).join('');
      }} catch(e) {{ document.getElementById('results').textContent = e.message; }}
    }}
    function escapeHtml(s) {{ return String(s).replace(/[&<>"']/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c])); }}
    refreshResults(); setInterval(refreshResults, 3000);
    </script></body></html>
    """)


@app.post("/vote/{vote_id}/cast")
async def cast_vote(vote_id: int, request: Request, option_index: int = Form(...)):
    user = request.session.get("user")
    if not user:
        return RedirectResponse("/login", status_code=303)
    try:
        member = await is_guild_member(user["id"])
    except Exception:
        raise HTTPException(503, "서버 멤버 확인에 실패했습니다. 잠시 후 다시 시도해 주세요.")
    if not member:
        request.session.clear()
        raise HTTPException(403, "지정된 디스코드 서버의 멤버만 투표할 수 있습니다.")

    async with pool.acquire() as conn:
        async with conn.transaction():
            vote = await conn.fetchrow("SELECT options FROM votes WHERE id=$1 FOR SHARE", vote_id)
            if not vote:
                raise HTTPException(404, "투표를 찾을 수 없습니다.")
            options = vote["options"]
            if isinstance(options, str):
                options = json.loads(options)
            if option_index < 0 or option_index >= len(options):
                raise HTTPException(400, "잘못된 선택지입니다.")
            try:
                await conn.execute(
                    "INSERT INTO ballots (vote_id, user_id, option_index) VALUES ($1,$2,$3)",
                    vote_id, user["id"], option_index
                )
            except asyncpg.UniqueViolationError:
                return HTMLResponse(
                    f'<meta charset="utf-8"><p>이미 투표했습니다. <a href="/vote/{vote_id}">결과로 돌아가기</a></p>',
                    status_code=409,
                )
    return RedirectResponse(f"/vote/{vote_id}", status_code=303)


@app.get("/api/vote/{vote_id}")
async def vote_results(vote_id: int, request: Request):
    user = request.session.get("user")
    if not user:
        raise HTTPException(401, "로그인이 필요합니다.")
    try:
        member = await is_guild_member(user["id"])
    except Exception:
        raise HTTPException(503, "서버 멤버 확인에 실패했습니다.")
    if not member:
        raise HTTPException(403, "지정된 서버 멤버만 결과를 볼 수 있습니다.")

    async with pool.acquire() as conn:
        vote = await conn.fetchrow("SELECT options FROM votes WHERE id=$1", vote_id)
        if not vote:
            raise HTTPException(404, "투표를 찾을 수 없습니다.")
        counts = await conn.fetch(
            "SELECT option_index, COUNT(*) AS count FROM ballots WHERE vote_id=$1 GROUP BY option_index",
            vote_id,
        )
    options = vote["options"]
    if isinstance(options, str):
        options = json.loads(options)
    count_map = {row["option_index"]: row["count"] for row in counts}
    total = sum(count_map.values())
    results = [
        {
            "option": option,
            "count": count_map.get(i, 0),
            "percent": round(count_map.get(i, 0) * 100 / total, 1) if total else 0,
        }
        for i, option in enumerate(options)
    ]
    return JSONResponse({"total": total, "results": results})


STYLE = """
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#0b1020;color:#eef2ff;
font-family:system-ui,-apple-system,Segoe UI,sans-serif}.wrap{max-width:720px;margin:48px auto;padding:16px}
.card{background:#151c30;border:1px solid #2a3552;border-radius:22px;padding:28px;box-shadow:0 20px 60px #0004}
.logo{font-size:44px}.topline,.muted{color:#9caad0;font-size:13px}h1{font-size:30px;margin:8px 0 12px}h2{font-size:20px}
a{color:#a9c5ff}.button{display:inline-block;background:#5865f2;color:white;border:0;border-radius:12px;
padding:13px 18px;text-decoration:none;font-weight:700;cursor:pointer;font-size:15px}.options{display:grid;gap:10px;margin:20px 0}
.option{display:flex;gap:12px;align-items:center;padding:14px;border:1px solid #34415f;border-radius:12px;cursor:pointer}
.option:has(input:checked){border-color:#8190ff;background:#20294b}.option input{accent-color:#7885ff;width:18px;height:18px}
.result{margin:14px 0}.result-head{display:flex;justify-content:space-between;gap:12px;margin-bottom:7px}
.bar{height:10px;background:#2a3552;border-radius:99px;overflow:hidden}.bar span{display:block;height:100%;background:#7885ff;border-radius:99px}
.success{padding:14px;background:#123a32;border-radius:12px;color:#b9ffdf}hr{border:0;border-top:1px solid #34415f;margin:24px 0}
</style>
"""


@app.on_event("startup")
async def startup():
    global bot_task
    await db_init()
    bot_task = asyncio.create_task(bot.start(DISCORD_TOKEN))
    print("웹 서버와 디스코드 봇 시작")


@app.on_event("shutdown")
async def shutdown():
    global bot_task
    if bot_task:
        bot_task.cancel()
    if not bot.is_closed():
        await bot.close()
    if pool:
        await pool.close()


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "10000")))
